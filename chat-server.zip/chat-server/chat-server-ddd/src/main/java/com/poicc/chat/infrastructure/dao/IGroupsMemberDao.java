package com.poicc.chat.infrastructure.dao;

import org.apache.ibatis.annotations.Mapper;

/**
 * @author mqxu
 */
@Mapper
public interface IGroupsMemberDao {
}
