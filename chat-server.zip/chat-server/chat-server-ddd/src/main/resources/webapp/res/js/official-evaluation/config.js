export const API_SAVE_COMMENT = '/campus/issue/official-evaluation/save.do' // 保存评论数据
export const API_FETCH_COMMENT = '/campus/issue/official-evaluation/query.do' // 获取评论数据
export const JFS_API_KEY = '65f48c1863314174932094c2c5278ba7'
export const API_UPLOAD_IMAGE = `https://ufo.jd.com/p/${JFS_API_KEY}` // 上传图片地址